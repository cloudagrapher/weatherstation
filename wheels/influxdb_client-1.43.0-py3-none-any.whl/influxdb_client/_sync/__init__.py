"""Synchronous REST APIs."""
